const routes = require("express").Router()
const Sequelize= require("sequelize")
const puppeteer = require("puppeteer")
let flags = require("../utils/obj")
const sequelize = new Sequelize("enot", "root", "", {
    dialect: "mysql"
});
routes.get("/", (req, res) => {
    sequelize.query(`SELECT * FROM filters`, { type: Sequelize.QueryTypes.SELECT }).then(result => {
        res.render("index", {
            data: result
        })
    })
})
routes.post("/", (req, res) => {
    res.redirect("/")
    if(req.body) {
        sequelize.query(`INSERT INTO filters VALUES (default, '${JSON.stringify(req.body)}')`)
    }
})
routes.get("/delete", (req, res) => {
    if(req.query.id) {
        sequelize.query(`DELETE FROM filters WHERE id= ${ req.query.id }`).then(() => {
            res.redirect('/')
        })
    }
})
routes.get("/login", (req, res) => {
    if(req.query) {
        
    }
})
module.exports = routes