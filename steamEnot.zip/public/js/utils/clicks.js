$("#popup").click(() => {
    $("#popup").animate({
        opacity:0
    }, 200)    
})