module.exports = {
    "authorized": false, // status of authorization into steam account
    "errors": false, // status of errors
    "parsingPages": [], // pages with skins, that should be parsed
}
